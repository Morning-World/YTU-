#ifndef SCHEDULER_H
#define SCHEDULER_H

#include "process.h"

void initialize_scheduler();
void add_to_ready_queue(Process* process);
Process* get_from_ready_queue();
void execute_next_process();
Process* get_from_Block_queue();
void add_to_Block_queue(Process* process);

#endif
